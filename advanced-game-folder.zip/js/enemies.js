
class Enemy {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 40;
        this.height = 40;
        this.color = 'red';
        this.health = 50;
        this.attackPower = 5;
        this.speed = 2;
        this.direction = { x: 1, y: 0 };
    }

    update(deltaTime) {
        this.x += this.direction.x * this.speed;
        this.y += this.direction.y * this.speed;
        if (this.x > 760 || this.x < 0) this.direction.x *= -1;
        if (this.y > 560 || this.y < 0) this.direction.y *= -1;
    }

    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}
