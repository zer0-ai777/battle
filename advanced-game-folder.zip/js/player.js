
class Player {
    constructor() {
        this.x = 100;
        this.y = 100;
        this.width = 40;
        this.height = 40;
        this.color = 'green';
        this.speed = 5;
        this.health = 100;
        this.attackPower = 10;
        this.inventory = new Inventory();
        this.direction = { x: 0, y: 0 };
        this.setControls();
    }

    setControls() {
        window.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowUp' || e.key === 'w') this.direction.y = -1;
            if (e.key === 'ArrowDown' || e.key === 's') this.direction.y = 1;
            if (e.key === 'ArrowLeft' || e.key === 'a') this.direction.x = -1;
            if (e.key === 'ArrowRight' || e.key === 'd') this.direction.x = 1;
        });

        window.addEventListener('keyup', (e) => {
            if (e.key === 'ArrowUp' || e.key === 'w') this.direction.y = 0;
            if (e.key === 'ArrowDown' || e.key === 's') this.direction.y = 0;
            if (e.key === 'ArrowLeft' || e.key === 'a') this.direction.x = 0;
            if (e.key === 'ArrowRight' || e.key === 'd') this.direction.x = 0;
        });
    }

    update(deltaTime) {
        this.x += this.direction.x * this.speed;
        this.y += this.direction.y * this.speed;
    }

    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}
