
class Inventory {
    constructor() {
        this.items = [];
    }

    addItem(item) {
        this.items.push(item);
    }

    useItem(itemIndex) {
        let item = this.items[itemIndex];
        // Implement item usage (healing, boosting stats, etc.)
    }
}
