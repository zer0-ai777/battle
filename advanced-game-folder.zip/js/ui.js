
// Display health bar, inventory, etc.
console.log("UI updated.");
